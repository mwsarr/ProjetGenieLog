package com.gildedrose;

import org.junit.jupiter.api.Test;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

class GildedRoseTest {

 
    //Test si la DLC décrémente
    @Test
    void testDecrementationSellin()
    {
    	Item[] items = new Item[] { new Item("Elixir of the Mongoose", 1, 0) };
        GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertThat(app.items[0].sellIn, is(0));
    }
   
    //test si la qualité décrémente
    @Test
    void testDecrementationQuality()
    {
    	Item[] items = new Item[] { new Item("Elixir of the Mongoose", 1, 1) };
        GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertThat(app.items[0].quality, is(0));
    }
    //item.quality <50 et item.sellin<11
    @Test
    void testQualitySulfuras()
    {
    	Item[] items = new Item[] { new Item("Sulfuras, Hand of Ragnaros", -1, 1) };
        GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertThat(app.items[0].quality, is(1));
    }

    // test pour vérifier backstage si la qualité va s'incrementer quand item.name = ("Backstage passes to a TAFKAL80 concert")
    @Test
    void testBackstageUpdate()
    {
    	Item[] items = new Item[] {new Item("Backstage passes to a TAFKAL80ETC concert",5,42)};
    	GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertThat(app.items[0].quality, is(45));
    }
  
    //test pour sellIn negatif
    @Test
    void testSellinNegatif()
    {
    	Item[] items = new Item[] {new Item("Elixir of the Mongoose",0,6)};
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	assertThat(app.items[0].quality,is(4));
    }

    //test avec Sellin negatif pour item...
    @Test
    void testBackstageWithsellInNegatif()
    {
    	Item[] items = new Item[]{new Item("Backstage passes to a TAFKAL80ETC concert",-1,3)};
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	assertThat(app.items[0].quality,is(0));
   
    }
    @Test
    void testAgedBrieWithsellInNegatif()
    {
    	Item[] items = new Item[]{new Item("Aged Brie",-1,3)};
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	assertThat(app.items[0].quality,is(5));
   
    }
    
   }
